# SENSI.PPSSPP
1. Install Android Studio (Koala or newer) -> File > Open -> select this SENSI folder -> let Gradle sync.
2. Plug in your phone (USB debugging) -> Run. Or Build > Build APK(s).
3. Install the free PPSSPP emulator from Play Store (org.ppsspp.ppsspp).
4. Allow "All files access" when SENSI asks.
5. Pro: in Play Console create an in-app product with ID `sensi_pro`, price $0.99, and upload the app to a testing track.
Games: use only games you own. SENSI includes no games or BIOS.
