package com.sensi.ppsspp

import android.media.*
import kotlin.math.*

/** Original synthesized "power-up aura" sounds (no copyrighted audio). */
object Sfx {
    private fun play(s: ShortArray, sr: Int) {
        Thread {
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(s.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
            t.write(s, 0, s.size); t.play()
            Thread.sleep(s.size * 1000L / sr + 200); t.release()
        }.start()
    }

    /** Rising harmonic scream + flame rumble + crackle + final energy burst (~3.4s). */
    fun powerUp() {
        val sr = 22050; val dur = 3.4; val n = (sr * dur).toInt(); val s = ShortArray(n)
        val rnd = java.util.Random(7); var p1 = 0.0; var p2 = 0.0; var p3 = 0.0; var lp = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / sr; val p = t / dur
            val env = min(1.0, t / 0.2) * (if (t > dur - 0.8) (dur - t) / 0.8 else 1.0)
            val f = 55 + p.pow(1.7) * 420
            p1 += 2 * PI * f / sr; p2 += 2 * PI * f * 2.01 / sr; p3 += 2 * PI * f * 3.0 / sr
            val tone = sin(p1) + 0.6 * sin(p2) + 0.35 * sin(p3)
            lp += ((rnd.nextDouble() * 2 - 1) - lp) * 0.08
            val crack = if (rnd.nextInt(700) == 0) (rnd.nextDouble() * 2 - 1) * 1.6 else 0.0
            val trem = 0.75 + 0.25 * sin(2 * PI * (8 + p * 22) * t)
            val burst = if (t > dur - 1.1 && t < dur - 0.8) (rnd.nextDouble() * 2 - 1) * 0.6 else 0.0
            val v = (tone * 0.27 * trem + lp * 1.7 * (0.4 + p) + crack * 0.3 + burst) * env
            s[i] = (v.coerceIn(-1.0, 1.0) * 30000).toInt().toShort()
        }
        play(s, sr)
    }

    /** Short energy zap for taps. */
    fun zap() {
        val sr = 22050; val n = (sr * 0.18).toInt(); val s = ShortArray(n); var ph = 0.0
        for (i in 0 until n) {
            val p = i.toDouble() / n; ph += 2 * PI * (700 + p * 1400) / sr
            s[i] = (sin(ph) * (1 - p) * 14000).toInt().toShort()
        }
        play(s, sr)
    }
}
