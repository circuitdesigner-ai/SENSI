package com.sensi.ppsspp

import android.app.*
import android.content.Intent
import android.os.*
import java.io.File

/** Real-time guard: any .apk that lands in Downloads/SENSI is quarantined (renamed .apk.blocked) so it can't be tapped to install. */
class ShieldService : Service() {
    private val observers = ArrayList<FileObserver>()
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("guard", "SENSI Guard", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "guard").setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("SENSI Shield active").setContentText("Blocking unknown APK installs").build())
        if (observers.isEmpty()) Shield.watched.filter { it.isDirectory }.forEach { dir ->
            val o = object : FileObserver(dir.path, CREATE or MOVED_TO or CLOSE_WRITE) {
                override fun onEvent(ev: Int, path: String?) {
                    if (path == null || !path.lowercase().endsWith(".apk")) return
                    Thread {
                        Thread.sleep(800)
                        val src = File(dir, path)
                        if (src.exists() && src.renameTo(File(dir, "$path.blocked"))) {
                            val n = Notification.Builder(this@ShieldService, "guard").setSmallIcon(android.R.drawable.ic_dialog_alert)
                                .setContentTitle("SENSI blocked an APK").setContentText(path).build()
                            nm.notify(path.hashCode(), n)
                        }
                    }.start()
                }
            }
            o.startWatching(); observers.add(o)
        }
        return START_STICKY
    }
    override fun onDestroy() { observers.forEach { it.stopWatching() }; observers.clear() }
}
