package com.sensi.ppsspp

import com.github.junrar.Archive
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.File
import java.util.zip.ZipInputStream

/** Real extraction: ZIP (built-in), 7Z (commons-compress), RAR (junrar). */
object Extractor {
    private fun safe(root: File, name: String): File {
        val f = File(root, name).canonicalFile
        require(f.path.startsWith(root.canonicalPath)) { "Blocked unsafe path: $name" }
        return f
    }
    private fun write(f: File, read: (ByteArray) -> Int) {
        f.parentFile?.mkdirs()
        f.outputStream().buffered().use { o ->
            val b = ByteArray(65536); var n: Int
            while (read(b).also { n = it } > 0) o.write(b, 0, n)
        }
    }
    fun ext(name: String) = name.substringAfterLast('.', "").lowercase()

    fun extract(src: File, out: File, onEntry: (Int, String) -> Unit) {
        out.mkdirs(); var count = 0
        when (ext(src.name)) {
            "zip" -> ZipInputStream(src.inputStream().buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val f = safe(out, e.name)
                    if (e.isDirectory) f.mkdirs() else write(f) { z.read(it) }
                    onEntry(++count, e.name); e = z.nextEntry
                }
            }
            "7z" -> SevenZFile(src).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val f = safe(out, e.name)
                    if (e.isDirectory) f.mkdirs() else write(f) { z.read(it) }
                    onEntry(++count, e.name); e = z.nextEntry
                }
            }
            "rar" -> Archive(src).use { a ->
                var h = a.nextFileHeader()
                while (h != null) {
                    val f = safe(out, h.fileName.replace('\\', '/'))
                    if (h.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { a.extractFile(h, it) } }
                    onEntry(++count, h.fileName); h = a.nextFileHeader()
                }
            }
            else -> error("Unsupported format: .${ext(src.name)} (use ZIP, 7Z or RAR)")
        }
    }
}
