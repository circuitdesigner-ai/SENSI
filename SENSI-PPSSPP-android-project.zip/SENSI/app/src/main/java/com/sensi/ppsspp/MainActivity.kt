package com.sensi.ppsspp

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StrictMode
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private val GOLD = Color.parseColor("#FFD21F"); private val FIRE = Color.parseColor("#FF7A00")
    private val BG = Color.parseColor("#0B0724"); private val CARD = Color.parseColor("#1D1553")
    private val MUTE = Color.parseColor("#A89FD6"); private val SPARK = Color.parseColor("#36D6FF")
    private val REQ_ARCHIVE = 1; private val REQ_GAME = 2
    private lateinit var prefs: SharedPreferences
    private lateinit var billing: Billing
    private lateinit var content: FrameLayout
    private lateinit var tabs: List<View>
    private lateinit var tabBtns: List<TextView>
    private lateinit var gamesList: LinearLayout
    private var isPro = false
    private var proShown = false
    private val freeFormats = setOf("zip")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build()) // lets PPSSPP open file:// game paths
        prefs = getSharedPreferences("sensi", MODE_PRIVATE)
        isPro = prefs.getBoolean("pro", false)
        billing = Billing(this) { isPro = true; prefs.edit().putBoolean("pro", true).apply(); toast("SENSI PRO unlocked ⚡") }
        billing.start()
        buildUi(); ensureAccess()
        if (!isPro) content.postDelayed({ if (!proShown && !isFinishing) showPro() }, 7000)
    }

    override fun onResume() { super.onResume(); refreshGames() }

    // ---------- permissions ----------
    private fun hasAll() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == 0

    private fun ensureAccess() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
        if (hasAll()) return
        AlertDialog.Builder(this).setTitle("Allow file access")
            .setMessage("SENSI needs access to your phone's files to extract archives, find your games and guard your Downloads folder.")
            .setPositiveButton("Allow") { _, _ ->
                if (Build.VERSION.SDK_INT >= 30)
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                else requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 8)
            }.setNegativeButton("Later", null).show()
    }

    // ---------- UI helpers ----------
    private fun grad(c1: Int, c2: Int, r: Int = 14) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply { cornerRadius = dp(r).toFloat() }
    private fun btn(t: String, alt: Boolean = false, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (alt) Color.parseColor("#04102A") else Color.parseColor("#2A1600"))
        background = if (alt) grad(SPARK, Color.parseColor("#7A6BFF")) else grad(GOLD, FIRE)
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) }
        setOnClickListener { Sfx.zap(); f() }
    }
    private fun label(t: String, size: Float = 15f, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, dp(6))
    }
    private fun page(vararg v: View) = ScrollView(this).apply {
        addView(LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(18)); v.forEach { addView(it) } })
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(8)) }
        head.addView(label("SENSI.PPSSPP", 28f, GOLD, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        head.addView(Button(this).apply {
            text = "★ PRO"; isAllCaps = false; setTextColor(Color.parseColor("#2A1600")); background = grad(GOLD, FIRE, 20)
            setOnClickListener { Sfx.zap(); showPro() }
        })
        content = FrameLayout(this)
        tabs = listOf(shieldTab(), gamesTab(), extractTab())
        tabs.forEach { content.addView(it, -1, -1) }
        val bar = LinearLayout(this).apply { setBackgroundColor(Color.parseColor("#100A33")) }
        tabBtns = listOf("🛡️ Shield", "🎮 Games", "📦 Extract").mapIndexed { i, n ->
            TextView(this).apply {
                text = n; textSize = 16f; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14)); typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f); setOnClickListener { Sfx.zap(); show(i) }
            }
        }
        tabBtns.forEach { bar.addView(it) }
        root.addView(head); root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(bar)
        setContentView(root); show(0)
    }

    private fun show(i: Int) {
        tabs.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabBtns.forEachIndexed { k, t -> t.setTextColor(if (k == i) GOLD else MUTE) }
        if (i == 1) refreshGames()
    }

    // ---------- Shield ----------
    private lateinit var status: TextView
    private lateinit var report: TextView
    private lateinit var flame: TextView
    private fun shieldTab(): View {
        flame = TextView(this).apply {
            text = "🔥"; textSize = 80f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(CARD); setStroke(dp(4), GOLD) }
            layoutParams = LinearLayout.LayoutParams(dp(190), dp(190)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(16) }
            setOnClickListener { powerUp() }
        }
        pulse(flame, 1.06f, 900)
        status = label("Tap the flame to power up", 18f, GOLD, true).apply { gravity = Gravity.CENTER }
        report = label("", 14f, Color.WHITE)
        return page(flame, status,
            btn("Scan apps & downloads") { runScan() },
            btn("Real-time guard (PRO): tap to turn on/off", true) { toggleGuardReal() },
            report)
    }

    private fun pulse(v: View, s: Float, ms: Long) {
        ObjectAnimator.ofPropertyValuesHolder(v,
            android.animation.PropertyValuesHolder.ofFloat("scaleX", 1f, s), android.animation.PropertyValuesHolder.ofFloat("scaleY", 1f, s)).apply {
            duration = ms; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start()
        }
    }
    private fun powerUp() {
        Sfx.powerUp(); status.text = "POWER LEVEL RISING…"
        flame.setTextColor(GOLD)
        ObjectAnimator.ofFloat(flame, "rotation", 0f, 8f, -8f, 6f, -6f, 0f).apply { duration = 3400; start() }
        flame.postDelayed({ status.text = "Fully protected ⚡" }, 3400)
    }
    private fun runScan() {
        if (!hasAll()) { ensureAccess(); return }
        Sfx.powerUp(); status.text = "SCANNING…"; report.text = ""
        Thread {
            val apps = Shield.scanApps(this); val apks = Shield.scanApks()
            runOnUiThread {
                status.text = if (apps.isEmpty() && apks.isEmpty()) "No threats found ✅" else "${apps.size + apks.size} item(s) need attention"
                report.text = (apks.map { "APK file: ${it.path}" } + apps).joinToString("\n\n")
                if (apks.isNotEmpty()) AlertDialog.Builder(this).setTitle("Found ${apks.size} APK file(s)")
                    .setMessage("Quarantine them so they can't be installed by accident?")
                    .setPositiveButton("Quarantine") { _, _ -> apks.forEach { it.renameTo(File(it.path + ".blocked")) }; toast("Quarantined") }
                    .setNegativeButton("Keep", null).show()
            }
        }.start()
    }
    private fun toggleGuardReal() {
        if (!isPro) { showPro(); return }
        if (!hasAll()) { ensureAccess(); return }
        val on = !prefs.getBoolean("guard", false)
        prefs.edit().putBoolean("guard", on).apply()
        val i = Intent(this, ShieldService::class.java)
        if (on) { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) } else stopService(i)
        toast(if (on) "Guard ON: new APKs are blocked" else "Guard OFF")
    }

    // ---------- Games ----------
    private fun gamesTab(): View {
        gamesList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        return page(label("Game library", 24f, GOLD, true),
            label("SENSI launches the PPSSPP emulator with your game. Install PPSSPP once, then pick any ISO, CSO or PBP you own.", 14f, MUTE),
            btn("Pick a game file") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, REQ_GAME) },
            label("Extracted games", 18f, Color.WHITE, true), gamesList)
    }
    private fun refreshGames() {
        if (!::gamesList.isInitialized) return
        gamesList.removeAllViews()
        val root = File(Environment.getExternalStorageDirectory(), "SENSI")
        val games = if (hasAll() && root.exists()) root.walkTopDown().filter { it.isFile && it.extension.lowercase() in setOf("iso", "cso", "pbp") }.toList() else emptyList()
        if (games.isEmpty()) gamesList.addView(label("Nothing here yet. Extract a game archive in the Extract tab.", 14f, MUTE))
        games.forEach { g -> gamesList.addView(btn("▶ " + g.nameWithoutExtension, true) { launchGame(Uri.fromFile(g)) }) }
    }
    private fun launchGame(uri: Uri) {
        Sfx.powerUp()
        for (pkg in listOf("org.ppsspp.ppssppgold", "org.ppsspp.ppsspp")) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW).setClassName(pkg, "org.ppsspp.ppsspp.PpssppActivity").setData(uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)); return
            } catch (e: ActivityNotFoundException) {}
        }
        AlertDialog.Builder(this).setTitle("PPSSPP not installed").setMessage("Install the free PPSSPP emulator, then try again.")
            .setPositiveButton("Open Play Store") { _, _ ->
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=org.ppsspp.ppsspp"))) }
                catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=org.ppsspp.ppsspp"))) }
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------- Extract ----------
    private lateinit var exStatus: TextView
    private fun extractTab(): View {
        exStatus = label("Supports ZIP (free), 7Z and RAR (PRO). Files go to /SENSI/<archive name>/", 14f, MUTE)
        return page(label("Extractor", 24f, GOLD, true), exStatus,
            btn("Choose archive", true) { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, REQ_ARCHIVE) })
    }
    private fun nameOf(u: Uri): String = contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "archive.zip"

    private fun extractUri(u: Uri) {
        if (!hasAll()) { ensureAccess(); return }
        val name = nameOf(u); val ext = Extractor.ext(name)
        if (ext !in freeFormats && !isPro) { showPro(); return }
        Sfx.powerUp(); exStatus.text = "Preparing $name…"
        Thread {
            try {
                val tmp = File(cacheDir, name)
                contentResolver.openInputStream(u)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 65536) } }
                val out = File(Environment.getExternalStorageDirectory(), "SENSI/" + name.substringBeforeLast('.'))
                Extractor.extract(tmp, out) { n, f -> if (n % 5 == 0) runOnUiThread { exStatus.text = "Extracting… $n files\n$f" } }
                tmp.delete()
                runOnUiThread { exStatus.text = "Done ✅ Saved to ${out.path}\nOpen the Games tab to play."; Sfx.zap() }
            } catch (e: Throwable) { runOnUiThread { exStatus.text = "Failed: ${e.message}" } }
        }.start()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == REQ_ARCHIVE) extractUri(u)
        if (req == REQ_GAME) launchGame(u)
    }

    // ---------- Pro popup ----------
    private fun showPro() {
        proShown = true
        if (isPro) { toast("You already have PRO ⚡"); return }
        AlertDialog.Builder(this).setTitle("⭐ SENSI PRO — ${billing.price}")
            .setMessage("One-time purchase:\n\n⚡ Real-time APK guard\n📦 7Z and RAR extraction\n🚫 No ads")
            .setPositiveButton("Unlock ${billing.price}") { _, _ -> billing.buy() }
            .setNegativeButton("Not now", null).show()
    }
}
