package com.sensi.ppsspp

import android.app.Activity
import com.android.billingclient.api.*

/** One-time "sensi_pro" product. Create it in Play Console as an in-app product priced at $0.99. */
class Billing(private val act: Activity, private val onPro: () -> Unit) {
    private var details: ProductDetails? = null
    private val client: BillingClient = BillingClient.newBuilder(act)
        .setListener { r, list -> if (r.responseCode == BillingClient.BillingResponseCode.OK) list?.forEach(::handle) }
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()).build()

    val price: String get() = details?.oneTimePurchaseOfferDetails?.formattedPrice ?: "$0.99"

    fun start() = client.startConnection(object : BillingClientStateListener {
        override fun onBillingServiceDisconnected() {}
        override fun onBillingSetupFinished(r: BillingResult) {
            if (r.responseCode != BillingClient.BillingResponseCode.OK) return
            val q = QueryProductDetailsParams.newBuilder().setProductList(listOf(
                QueryProductDetailsParams.Product.newBuilder().setProductId("sensi_pro").setProductType(BillingClient.ProductType.INAPP).build())).build()
            client.queryProductDetailsAsync(q) { _, l -> details = l.firstOrNull() }
            client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()) { _, l -> l.forEach(::handle) }
        }
    })

    fun buy() {
        val d = details ?: return
        val p = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).build()
        client.launchBillingFlow(act, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(p)).build())
    }

    private fun handle(p: Purchase) {
        if (p.purchaseState != Purchase.PurchaseState.PURCHASED) return
        if (!p.isAcknowledged) client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) {}
        act.runOnUiThread(onPro)
    }
}
