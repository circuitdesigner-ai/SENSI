package com.sensi.ppsspp

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File

object Shield {
    val watched: List<File> get() = listOf(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        File(Environment.getExternalStorageDirectory(), "SENSI"))

    fun scanApks(): List<File> = watched.flatMap { d ->
        d.walkTopDown().maxDepth(3).filter { it.isFile && it.name.lowercase().endsWith(".apk") }.toList()
    }

    fun scanApps(ctx: Context): List<String> {
        val pm = ctx.packageManager; val out = ArrayList<String>()
        val risky = mapOf(
            "android.permission.SYSTEM_ALERT_WINDOW" to "draws over apps",
            "android.permission.REQUEST_INSTALL_PACKAGES" to "can install apps",
            "android.permission.READ_SMS" to "reads SMS",
            "android.permission.RECEIVE_SMS" to "intercepts SMS",
            "android.permission.BIND_DEVICE_ADMIN" to "device admin")
        for (pi in pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)) {
            val ai = pi.applicationInfo ?: continue
            if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0 || pi.packageName == ctx.packageName) continue
            val installer = try {
                if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pi.packageName).installingPackageName
                else pm.getInstallerPackageName(pi.packageName)
            } catch (e: Exception) { null }
            val hits = (pi.requestedPermissions ?: emptyArray()).mapNotNull { risky[it] }
            val side = installer == null
            if (hits.size >= 2 || (side && hits.isNotEmpty()))
                out.add("${pm.getApplicationLabel(ai)}: ${hits.joinToString()}" + if (side) " (sideloaded)" else "")
        }
        val acc = Settings.Secure.getString(ctx.contentResolver, "enabled_accessibility_services")
        if (!acc.isNullOrBlank()) acc.split(':').forEach { out.add("Accessibility service ON: ${it.substringBefore('/')}") }
        return out
    }
}
